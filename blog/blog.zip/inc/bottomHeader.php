<header>
         <div class="container">
            <div class="logo">
               <a href=""> <img src="images/logo.png"> </a>
            </div>
            <div class="navbar-handler">
               <img src="images/hamburger.png">
            </div>
            <div class="navbar-custom">
               <div class="menu-item">
                  <a href="index.html"> Home </a>   
               </div>
               <div class="menu-item">
                  <a href="services.html"> Services </a>  
               </div>
               <div class="menu-item">
                  <a href="about.html"> About Us </a>  
               </div>
               <div class="menu-item">
                  <a href="jobs.html"> Gallery </a>   
               </div>
               <div class="menu-item">
                  <a href="contact.html"> Contact Us </a>   
               </div>
               <div class="menu-item">
                  <a href="blog.php"> Blog </a>   
               </div>
               
            </div>
         </div>
      </header>

<!-- Service Banner Section Starts Here -->
<section class="service-header">
   <img src="images/service-header.jpg">
</section>
<!-- Service Banner Section Ends Here -->