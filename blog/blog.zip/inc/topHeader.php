<!-- Top Bar Section Starts Here -->
<section class="top-bar">
 <div class="container">
    <div class="row">
       <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
          <div class="top-bar-left">
             <h6> Our Ratings: 
                <span> <i class="fa fa-star"> </i> <i class="fa fa-star"> </i> <i class="fa fa-star"> </i> <i class="fa fa-star"> </i> <i class="fa fa-star"> </i> <b> 5 out of 5 </b> </span>
             </h6>
          </div>
       </div>
       <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
          <div class="top-bar-right">
             <span> <i class="fa fa-envelope"> </i> contact@deckrestorationservices.com </span>   
             <span> <i class="fa fa-phone"> </i> 773 664 8791  </span>
          </div>
       </div>
    </div>
 </div>
</section>